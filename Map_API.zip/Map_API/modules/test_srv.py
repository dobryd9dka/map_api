import json
from http.server import HTTPServer, SimpleHTTPRequestHandler


# Пример простого локального сервера по порту 5000, возвращающего json-структуру
class Handler(SimpleHTTPRequestHandler):

    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(
            str.encode(json.dumps({
                "check": "b0f66adc83641586656866813fd9dd0b8ebb63796075661ba45d1aa8089e1d44",
                "result": [
                    2,
                    8
                ]
            })))


httpd = HTTPServer(('127.0.0.1', 5000), Handler)
httpd.serve_forever()
