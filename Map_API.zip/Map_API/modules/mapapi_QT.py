import os
import sys

from PIL import Image, ImageQt
from io import BytesIO
import requests
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QWidget, QLabel


class MapImage(QWidget):
    def __init__(self, ll, spn, l_type, add_param):
        super().__init__()
        self.SCREEN_SIZE = [600, 450]
        self.getImage(ll, spn, l_type, add_param)
        self.initUI()

    def getImage(self, ll, spn='0.002,0.002', l_type='map', add_param=""):
        map_request = f"http://static-maps.yandex.ru/1.x/?ll={ll}&spn={spn}&l={l_type}&{add_param}"
        response = requests.get(map_request)

        if not response:
            print("Ошибка выполнения запроса:")
            print(map_request)
            print("Http статус:", response.status_code, "(", response.reason, ")")
            sys.exit(1)

        self.img_map = Image.open(BytesIO(response.content))
        self.img = ImageQt.ImageQt(self.img_map)
        # В принципе, никто не мешает смотреть получаемые изображения средствами системы
        # img_map.show()
        # И даже сохранить это в файл
        # img_map.save("map.png")

    def save(self):
        self.img_map.save("map.png")

    def initUI(self):
        self.setGeometry(200, 200, *self.SCREEN_SIZE)
        self.setWindowTitle('Отображение карты')

        ## Изображение
        self.image = QLabel(self)
        self.image.move(0, 0)
        self.image.resize(600, 450)
        self.image.setPixmap(QPixmap.fromImage(self.img))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    # Для примера - карта Австралии со спутника
    map_img = MapImage("135.746181,-27.483765", "20,20", "sat")
    map_img.show()
    sys.exit(app.exec())
