import sys
from PyQt5.QtWidgets import QApplication
from modules.mapapi_QT import MapImage
from modules.geocoder import get_coordinates, get_ll_span


def show_maps():
    toponym_to_find = " ".join(sys.argv[1:])

    if toponym_to_find:
        # Показываем карту с фиксированным масштабом.
        lat, lon = get_coordinates(toponym_to_find)
        map_locations = (f"{lat},{lon}", "0.005,0.005", "map")

        # Показываем карту с масштабом, подобранным по заданному объекту.
        ll, spn = get_ll_span(toponym_to_find)
        map_locations = (ll, spn, "map")

        # Добавляем исходную точку на карту.
        add_param = f"pt={ll}"
        map_locations = (ll, spn, "map", add_param)

        map_location, map_spn, map_type, add_param = map_locations
        app = QApplication(sys.argv)
        map_img = MapImage(map_location, map_spn, map_type, add_param)
        map_img.show()
        map_img.save()
        sys.exit(app.exec())
    else:
        print('No data')


def main():
    show_maps()


if __name__ == "__main__":
    main()
