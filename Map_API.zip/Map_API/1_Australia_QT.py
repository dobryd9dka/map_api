import sys
from PyQt5.QtWidgets import QApplication
from modules.mapapi_QT import MapImage


def show_maps():
    # Параметры позиционирования карты и ее тип.
    map_locations = {
        "Австралия": ("135.746181,-27.483765", "20,20", "sat")
    }

    for map_location, map_spn, map_type in map_locations.values():
        app = QApplication(sys.argv)
        map_img = MapImage(map_location, map_spn, map_type)
        map_img.show()
        sys.exit(app.exec())


def main():
    # Показать спутниковый снимок Австралии
    show_maps()


if __name__ == "__main__":
    main()
